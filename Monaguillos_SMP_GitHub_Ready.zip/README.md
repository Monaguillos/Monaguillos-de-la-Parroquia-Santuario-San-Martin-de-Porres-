
# Monaguillos · Parroquia Santuario San Martín de Porres

Proyecto web listo para subir a GitHub Pages.

## Estructura
- `index.html`
- `style.css`
- `script.js`
- `media/`
  - `logo.png`
  - `bienvenida.mp4`
  - `la-fila-hakuna.mp3`
  - `huracan-hakuna.mp3`
  - `hasta-la-locura-banda-huellas.mp3`
  - `para-quien-soy-yo-hakuna-group.mp3`
  - `foto1.jpg`
  - `foto2.jpg`
  - `foto3.jpg`

## Cómo subirlo a GitHub
1. Abre tu repositorio.
2. Pulsa **Add file** → **Upload files**.
3. Sube `index.html`, `style.css`, `script.js` y la carpeta `media` con tus archivos.
4. Pulsa **Commit changes**.
5. Ve a **Settings** → **Pages**.
6. En **Build and deployment**, selecciona:
   - **Source:** Deploy from a branch
   - **Branch:** `main`
   - **Folder:** `/ (root)`
7. Guarda y espera unos minutos.

## Cómo subir el video, la música y las imágenes
- Video de bienvenida: coloca tu archivo como `media/bienvenida.mp4`.
- Música: coloca tus audios como:
  - `media/la-fila-hakuna.mp3`
  - `media/huracan-hakuna.mp3`
  - `media/hasta-la-locura-banda-huellas.mp3`
  - `media/para-quien-soy-yo-hakuna-group.mp3`
- Imágenes: agrega fotos en `media/` y usa nombres como `foto1.jpg`, `foto2.jpg`, `foto3.jpg`.

Si luego cambias el nombre de un archivo, también debes cambiarlo en `index.html` o `script.js`.
