
document.addEventListener('DOMContentLoaded', () => {
  const topbar = document.getElementById('topbar');
  const menuToggle = document.getElementById('menuToggle');
  const mobileMenu = document.getElementById('mobileMenu');
  const revealEls = document.querySelectorAll('.reveal');
  const yearsService = document.getElementById('yearsService');
  const membersCount = document.getElementById('membersCount');
  const meetingsCount = document.getElementById('meetingsCount');
  const cdDays = document.getElementById('cdDays');
  const cdHours = document.getElementById('cdHours');
  const cdMinutes = document.getElementById('cdMinutes');
  const cdSeconds = document.getElementById('cdSeconds');
  const cdMessage = document.getElementById('cdMessage');
  const nextCelebration = document.getElementById('nextCelebration');
  const calendarEl = document.getElementById('calendar');
  const monthNameEl = document.getElementById('monthName');
  const prevMonth = document.getElementById('prevMonth');
  const nextMonth = document.getElementById('nextMonth');
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightboxImg');
  const closeLightbox = document.getElementById('closeLightbox');
  const musicPanel = document.getElementById('musicPanel');
  const musicOpen = document.getElementById('musicOpen');
  const musicOpen2 = document.getElementById('musicOpen2');
  const musicClose = document.getElementById('musicClose');
  const audioPlayer = document.getElementById('audioPlayer');
  const musicList = document.getElementById('musicList');
  const themeLabel = document.getElementById('themeLabel');
  const themeDot = document.querySelector('.theme-dot');
  const themeChip = document.getElementById('themeChip');
  const floatTop = document.querySelector('.float-top');

  if (topbar) {
    window.addEventListener('scroll', () => topbar.classList.toggle('scrolled', window.scrollY > 8));
  }

  if (menuToggle && mobileMenu) {
    menuToggle.addEventListener('click', () => {
      const open = mobileMenu.hasAttribute('hidden');
      if (open) mobileMenu.removeAttribute('hidden');
      else mobileMenu.setAttribute('hidden', '');
      menuToggle.setAttribute('aria-expanded', String(open));
    });
    mobileMenu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
      mobileMenu.setAttribute('hidden', '');
      menuToggle.setAttribute('aria-expanded', 'false');
    }));
  }

  const io = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) entry.target.classList.add('visible');
    });
  }, {threshold: 0.14});
  revealEls.forEach(el => io.observe(el));

  function animateCount(el, end, duration = 1600){
    if (!el) return;
    const start = 0;
    const t0 = performance.now();
    const step = (t) => {
      const p = Math.min((t - t0) / duration, 1);
      const value = Math.floor(start + (end - start) * (1 - Math.pow(1 - p, 3)));
      el.textContent = value;
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }
  animateCount(yearsService, 18);
  animateCount(membersCount, 240);
  animateCount(meetingsCount, 720);

  function nextSunday5pm(now = new Date()){
    const target = new Date(now);
    const day = target.getDay();
    let diffDays = (7 - day) % 7;
    target.setHours(17,0,0,0);
    if (diffDays === 0 && now >= target) diffDays = 7;
    target.setDate(target.getDate() + diffDays);
    return target;
  }
  function updateCountdown(){
    if (!cdDays || !cdHours || !cdMinutes || !cdSeconds || !cdMessage) return;
    const now = new Date();
    const target = nextSunday5pm(now);
    const diff = target - now;
    if (diff <= 0) {
      cdMessage.textContent = '¡La reunión está comenzando! Te esperamos en la parroquia.';
      return;
    }
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
    const minutes = Math.floor((diff / (1000 * 60)) % 60);
    const seconds = Math.floor((diff / 1000) % 60);
    cdDays.textContent = String(days).padStart(2, '0');
    cdHours.textContent = String(hours).padStart(2, '0');
    cdMinutes.textContent = String(minutes).padStart(2, '0');
    cdSeconds.textContent = String(seconds).padStart(2, '0');
    cdMessage.textContent = 'Reunión de monaguillos todos los domingos a las 5:00 p. m.';
  }
  updateCountdown();
  setInterval(updateCountdown, 1000);

  function easterDate(year){
    const a = year % 19, b = Math.floor(year / 100), c = year % 100, d = Math.floor(b / 4), e = b % 4, f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3), h = (19 * a + b - d - g + 15) % 30, i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451), month = Math.floor((h + l - 7 * m + 114) / 31) - 1, day = ((h + l - 7 * m + 114) % 31) + 1;
    return new Date(year, month, day);
  }
  function firstSundayOfAdvent(year){
    const christmas = new Date(year, 11, 25);
    const start = new Date(christmas);
    start.setDate(christmas.getDate() - 28);
    while (start.getDay() !== 0) start.setDate(start.getDate() + 1);
    return start;
  }
  function baptismOfLord(year){
    const jan6 = new Date(year, 0, 6);
    const sundayAfterJan6 = new Date(jan6);
    do { sundayAfterJan6.setDate(sundayAfterJan6.getDate() + 1); } while (sundayAfterJan6.getDay() !== 0);
    return sundayAfterJan6;
  }
  function corpusChristi(year){ return new Date(easterDate(year).getTime() + 60 * 24 * 60 * 60 * 1000); }
  function ashWednesday(year){ return new Date(easterDate(year).getTime() - 46 * 24 * 60 * 60 * 1000); }
  function palmSunday(year){ return new Date(easterDate(year).getTime() - 7 * 24 * 60 * 60 * 1000); }
  function holyThursday(year){ return new Date(easterDate(year).getTime() - 3 * 24 * 60 * 60 * 1000); }
  function goodFriday(year){ return new Date(easterDate(year).getTime() - 2 * 24 * 60 * 60 * 1000); }
  function holySaturday(year){ return new Date(easterDate(year).getTime() - 1 * 24 * 60 * 60 * 1000); }
  function pentecost(year){ return new Date(easterDate(year).getTime() + 49 * 24 * 60 * 60 * 1000); }
  function trinitySunday(year){ return new Date(easterDate(year).getTime() + 56 * 24 * 60 * 60 * 1000); }
  function sacredHeart(year){ return new Date(easterDate(year).getTime() + 68 * 24 * 60 * 60 * 1000); }
  function christTheKing(year){
    const nov23 = new Date(year, 10, 23);
    const d = new Date(nov23);
    while (d.getDay() !== 0) d.setDate(d.getDate() + 1);
    return d;
  }

  function liturgicalSeason(date){
    const year = date.getFullYear();
    const easter = easterDate(year);
    const ash = ashWednesday(year);
    const holyThu = holyThursday(year);
    const holySat = holySaturday(year);
    const pent = pentecost(year);
    const advent = firstSundayOfAdvent(year);
    const baptism = baptismOfLord(year);
    const christmasStart = new Date(year, 11, 25);
    const christmasEnd = baptism;
    if (date >= advent && date < christmasStart) return {season:'Adviento', color:'violet'};
    if ((date >= christmasStart && date <= christmasEnd) || (date.getMonth() === 11 && date.getDate() === 25)) return {season:'Navidad', color:'white'};
    if (date >= ash && date < holyThu) return {season:'Cuaresma', color:'violet'};
    if (date >= holyThu && date <= holySat) return {season:'Triduo Pascual', color:'red'};
    if (date >= easter && date <= pent) return {season:'Pascua', color:'white'};
    return {season:'Tiempo ordinario', color:'green'};
  }

  function applyLiturgicalTheme(){
    const current = liturgicalSeason(new Date());
    const palette = {
      green:{primary:'#7ba05b', secondary:'#2e3d24', accent:'#eef7e6', border:'rgba(123,160,91,.24)'},
      violet:{primary:'#7a5ab3', secondary:'#35264f', accent:'#f2ecff', border:'rgba(122,90,179,.24)'},
      white:{primary:'#f4efe6', secondary:'#8d7860', accent:'#ffffff', border:'rgba(244,239,230,.24)'},
      red:{primary:'#c85a4a', secondary:'#4d251f', accent:'#fff1ee', border:'rgba(200,90,74,.24)'}
    }[current.color];
    const root = document.documentElement;
    root.style.setProperty('--primary', palette.primary);
    root.style.setProperty('--secondary', palette.secondary);
    root.style.setProperty('--accent', palette.accent);
    root.style.setProperty('--border', palette.border);
    if (themeLabel) themeLabel.textContent = current.season;
    if (themeDot) themeDot.style.background = palette.primary;
    if (themeChip) themeChip.style.borderColor = palette.border;
    if (floatTop){
      floatTop.style.background = `linear-gradient(135deg, ${palette.primary}, #f2deb0)`;
      floatTop.style.color = '#2d1b10';
    }
  }
  applyLiturgicalTheme();

  function eventCatalog(year){
    const easter = easterDate(year);
    const ash = ashWednesday(year), palm = palmSunday(year), holyThu = holyThursday(year), goodFri = goodFriday(year), holySat = holySaturday(year), pent = pentecost(year), trinity = trinitySunday(year), corpus = corpusChristi(year), sacred = sacredHeart(year), christ = christTheKing(year), advent = firstSundayOfAdvent(year), baptism = baptismOfLord(year);
    const fixed = [
      {date:new Date(year,0,1), title:'Santa María Madre de Dios', icon:'👑', color:'white'},
      {date:baptism, title:'Bautismo del Señor', icon:'🕊️', color:'white'},
      {date:new Date(year,1,2), title:'Presentación del Señor', icon:'✨', color:'white'},
      {date:new Date(year,2,19), title:'San José', icon:'🛠️', color:'white'},
      {date:new Date(year,2,25), title:'Anunciación del Señor', icon:'🌸', color:'white'},
      {date:new Date(year,4,1), title:'San José Obrero', icon:'🛠️', color:'white'},
      {date:new Date(year,5,29), title:'San Pedro y San Pablo', icon:'🔴', color:'red'},
      {date:new Date(year,7,15), title:'Asunción de la Virgen María', icon:'👑', color:'white'},
      {date:new Date(year,10,1), title:'Todos los Santos', icon:'✨', color:'white'},
      {date:new Date(year,10,2), title:'Fieles Difuntos', icon:'🕯️', color:'violet'},
      {date:new Date(year,10,3), title:'San Martín de Porres', icon:'⛪', color:'gold'},
      {date:new Date(year,11,8), title:'Inmaculada Concepción', icon:'🌼', color:'white'},
      {date:new Date(year,11,25), title:'Navidad del Señor', icon:'🎄', color:'white'},
      {date:new Date(year,6,19), title:'Kermes parroquial', icon:'🎉', color:'gold'}
    ];
    const movable = [
      {date:ash, title:'Miércoles de Ceniza', icon:'✝', color:'violet'},
      {date:palm, title:'Domingo de Ramos', icon:'🌿', color:'red'},
      {date:holyThu, title:'Jueves Santo', icon:'⛪', color:'white'},
      {date:goodFri, title:'Viernes Santo', icon:'✝', color:'red'},
      {date:holySat, title:'Sábado Santo', icon:'🕯️', color:'violet'},
      {date:easter, title:'Domingo de Pascua', icon:'✨', color:'white'},
      {date:new Date(easter.getTime() + 7 * 24 * 60 * 60 * 1000), title:'Divina Misericordia', icon:'🤍', color:'white'},
      {date:pent, title:'Pentecostés', icon:'🕊️', color:'red'},
      {date:trinity, title:'Santísima Trinidad', icon:'✝', color:'white'},
      {date:corpus, title:'Corpus Christi', icon:'👑', color:'white'},
      {date:sacred, title:'Sagrado Corazón de Jesús', icon:'❤️', color:'red'},
      {date:christ, title:'Cristo Rey del Universo', icon:'👑', color:'white'},
      {date:advent, title:'Primer Domingo de Adviento', icon:'🕯️', color:'violet'}
    ];
    return [...fixed, ...movable]
      .filter(e => e.date.getFullYear() === year)
      .map(e => ({...e, key:`${e.date.getMonth()}-${e.date.getDate()}`}));
  }

  let viewDate = new Date();
  const weekdays = ['Dom','Lun','Mar','Mié','Jue','Vie','Sáb'];

  function renderCalendar(date){
    if (!calendarEl || !monthNameEl) return;
    const year = date.getFullYear();
    const month = date.getMonth();
    const events = eventCatalog(year);
    monthNameEl.textContent = date.toLocaleDateString('es-PE', {month:'long', year:'numeric'});
    calendarEl.innerHTML = '';

    weekdays.forEach(d => {
      const el = document.createElement('div');
      el.className = 'dow';
      el.textContent = d;
      calendarEl.appendChild(el);
    });

    const first = new Date(year, month, 1);
    const startDay = first.getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const prevDays = new Date(year, month, 0).getDate();
    const today = new Date();

    for(let i=0; i<42; i++){
      const cell = document.createElement('div');
      cell.className = 'day';
      let dayNum;
      let isMuted = false;

      if (i < startDay){
        dayNum = prevDays - startDay + 1 + i;
        isMuted = true;
      } else if (i >= startDay + daysInMonth){
        dayNum = i - (startDay + daysInMonth) + 1;
        isMuted = true;
      } else {
        dayNum = i - startDay + 1;
        if (dayNum === today.getDate() && month === today.getMonth() && year === today.getFullYear()) {
          cell.classList.add('today');
        }
      }

      cell.innerHTML = `<div class="num">${dayNum}</div>`;

      if (!isMuted){
        const current = new Date(year, month, dayNum);
        const season = liturgicalSeason(current);

        const seasonBadge = document.createElement('span');
        seasonBadge.className = `badge ${season.color}`;
        seasonBadge.textContent = season.season;
        cell.appendChild(seasonBadge);

        if (current.getDay() === 0){
          const ev = document.createElement('span');
          ev.className = 'badge meeting';
          ev.textContent = 'Reunión 5:00 p. m.';
          cell.appendChild(ev);
        }

        events.filter(e => e.key === `${month}-${dayNum}`).forEach(e => {
          const ev = document.createElement('span');
          ev.className = `badge ${e.color}`;
          ev.textContent = `${e.icon} ${e.title}`;
          cell.appendChild(ev);
        });
      } else {
        cell.classList.add('muted');
      }

      calendarEl.appendChild(cell);
    }

    updateNextCelebration(events);
  }

  function updateNextCelebration(events){
    if (!nextCelebration) return;
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const future = [...events]
      .map(e => ({...e, time: e.date.getTime()}))
      .filter(e => e.time >= todayStart)
      .sort((a,b)=>a.time-b.time);

    if (!future.length) {
      nextCelebration.textContent = 'No hay celebraciones próximas cargadas para este año.';
      return;
    }

    const next = future[0];
    const diff = next.time - now.getTime();
    const days = Math.max(0, Math.floor(diff / (1000*60*60*24)));
    nextCelebration.textContent = `Próxima celebración: ${next.icon} ${next.title} — ${next.date.toLocaleDateString('es-PE', {day:'2-digit', month:'long'})} · faltan ${days} días.`;
  }

  renderCalendar(viewDate);
  if (prevMonth) prevMonth.addEventListener('click', ()=>{
    viewDate = new Date(viewDate.getFullYear(), viewDate.getMonth()-1, 1);
    renderCalendar(viewDate);
  });
  if (nextMonth) nextMonth.addEventListener('click', ()=>{
    viewDate = new Date(viewDate.getFullYear(), viewDate.getMonth()+1, 1);
    renderCalendar(viewDate);
  });

  const tracks = [
    {name:'La Fila - Hakuna', src:'media/la-fila-hakuna.mp3'},
    {name:'Huracán - Hakuna', src:'media/huracan-hakuna.mp3'},
    {name:'Hasta la locura - Banda Huellas', src:'media/hasta-la-locura-banda-huellas.mp3'},
    {name:'Para quién soy yo - Hakuna Group', src:'media/para-quien-soy-yo-hakuna-group.mp3'}
  ];

  function renderTracks(){
    if (!musicList || !audioPlayer) return;
    musicList.innerHTML = '';
    tracks.forEach((t, i) => {
      const btn = document.createElement('button');
      btn.textContent = t.name;
      btn.addEventListener('click', () => {
        audioPlayer.src = t.src;
        audioPlayer.play().catch(()=>{});
        [...musicList.children].forEach(c => c.classList.remove('active'));
        btn.classList.add('active');
      });
      if (i === 0) btn.classList.add('active');
      musicList.appendChild(btn);
    });
    audioPlayer.src = tracks[0].src;
  }
  renderTracks();

  const openMusic = () => { if (musicPanel) musicPanel.classList.add('open'); };
  if (musicOpen) musicOpen.addEventListener('click', openMusic);
  if (musicOpen2) musicOpen2.addEventListener('click', openMusic);
  if (musicClose) musicClose.addEventListener('click', ()=> musicPanel.classList.remove('open'));

  document.querySelectorAll('.gallery-card').forEach(card => {
    card.addEventListener('click', () => {
      if (!lightbox || !lightboxImg) return;
      lightboxImg.src = '';
      lightboxImg.alt = 'Galería oficial';
      lightbox.classList.add('open');
      lightbox.setAttribute('aria-hidden', 'false');
    });
  });

  function closeLb(){
    if (!lightbox) return;
    lightbox.classList.remove('open');
    lightbox.setAttribute('aria-hidden', 'true');
  }
  if (closeLightbox) closeLightbox.addEventListener('click', closeLb);
  if (lightbox) lightbox.addEventListener('click', (e) => {
    if (e.target === lightbox) closeLb();
  });

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeLb();
      if (musicPanel) musicPanel.classList.remove('open');
    }
  });
});
