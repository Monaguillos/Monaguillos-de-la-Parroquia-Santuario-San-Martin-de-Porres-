
# Carpeta media

Coloca aquí tus archivos reales:

- `logo.png`
- `bienvenida.mp4`
- `la-fila-hakuna.mp3`
- `huracan-hakuna.mp3`
- `hasta-la-locura-banda-huellas.mp3`
- `para-quien-soy-yo-hakuna-group.mp3`
- `foto1.jpg`
- `foto2.jpg`
- `foto3.jpg`

Si no subes un archivo con el nombre exacto, la página no podrá cargarlo.
